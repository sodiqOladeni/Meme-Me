//
//  MemeCollectionViewCell.swift
//  MemeMe 1.0
//
//  Created by sodiqOladeni on 15/03/2020.
//  Copyright © 2020 NotZero Technologies. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var contentImageView: UIImageView!
        
}
